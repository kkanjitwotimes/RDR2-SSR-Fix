RDR2 Vulkan Overscan*

A customizable mod that effectively crops the viewport, allowing screen-space to see 'off-screen', mitigating edge screen artifacting.

Put RDR2OverscanVK.asi inside the RDR2 root

On first run it creates the config file (RDR2Overscan.ini) next to the ASI, you can edit it while the game runs (checked about once per second, reloaded only when the file has been saved)

Zoom is responsible for the amount of, well, zoom, higher number = less artifacts but narrower FOV.

HoldZoomOnPause=1 (default) keeps the zoom engaged while paused so the background no longer unzooms and re-ramps; 0 restores the old behaviour. EngageFrames and RampFrames control a zoom function on menu enter and exit, previously exiting a menu/loading in caused the zoom and not-zoomed view to fight and flicker, this jank-i-ly fixes that by employing EngageFrames (how many frames after unpausing until it starts zooming in) and RampFrames (how many frames until fully zoomed)

Sharpness=0.0 (default off) enables AMD FidelityFX CAS sharpening on the zoomed 3D scene only (UI untouched): 0.3-0.6 is a sensible range, 1.0 strongest. Applies live. If the pass cannot be built the plain zoom is kept (capture log: sharpen=on / FAILED: reason).
